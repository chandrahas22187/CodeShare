package springerNature.Enums;

/**
 * @author Chandrahas
 */
public enum TeaCodes {
    TM, TL, TI
}
