package springerNature.Enums;

/**
 * @author Chandrahas
 */
public enum CoffeeCodes {
    CC, CL, CM
}
