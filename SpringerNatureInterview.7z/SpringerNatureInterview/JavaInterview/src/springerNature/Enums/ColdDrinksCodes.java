package springerNature.Enums;

/**
 * @author Chandrahas
 */
public enum ColdDrinksCodes {
    CDC, CDP, CDS
}
