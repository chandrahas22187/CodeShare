package springerNature.abstraction;

/**
 * @author Chandrahas
 */
public interface Meals {

    double getPrice();
}
