package springerNature.abstraction;

/**
 * @author Chandrahas
 */
public interface Coffee_Interface extends Meals {

    @Override
    double getPrice();
}
