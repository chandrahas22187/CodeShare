package springerNature.abstraction;

/**
 * @author Chandrahas
 */
public interface ColdDrink_Interface extends Meals {

    @Override
    double getPrice();
}
