package springerNature.abstraction;

/**
 * @author Chandrahas
 */
public interface Tea_Interface extends Meals {

    @Override
    double getPrice();
}
